﻿namespace TempConverterwithRadioButtons
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtOutput = new System.Windows.Forms.TextBox();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioToFah = new System.Windows.Forms.RadioButton();
            this.radioToCels = new System.Windows.Forms.RadioButton();
            this.radioToKelv = new System.Windows.Forms.RadioButton();
            this.btnConvert = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioFromKelv = new System.Windows.Forms.RadioButton();
            this.radioFromCels = new System.Windows.Forms.RadioButton();
            this.radioFromFah = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtInput);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(22, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(433, 59);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtOutput);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(22, 317);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(433, 68);
            this.panel2.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Input Temperature:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(18, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(171, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Output Temperature";
            // 
            // txtOutput
            // 
            this.txtOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOutput.ForeColor = System.Drawing.Color.Red;
            this.txtOutput.Location = new System.Drawing.Point(204, 24);
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.ReadOnly = true;
            this.txtOutput.Size = new System.Drawing.Size(172, 29);
            this.txtOutput.TabIndex = 1;
            this.txtOutput.TabStop = false;
            this.txtOutput.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtInput
            // 
            this.txtInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInput.Location = new System.Drawing.Point(204, 14);
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(175, 29);
            this.txtInput.TabIndex = 0;
            this.txtInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.radioToKelv);
            this.groupBox1.Controls.Add(this.radioToCels);
            this.groupBox1.Controls.Add(this.radioToFah);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(274, 97);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(181, 132);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "To";
            // 
            // radioToFah
            // 
            this.radioToFah.AutoSize = true;
            this.radioToFah.Location = new System.Drawing.Point(18, 25);
            this.radioToFah.Name = "radioToFah";
            this.radioToFah.Size = new System.Drawing.Size(137, 24);
            this.radioToFah.TabIndex = 0;
            this.radioToFah.TabStop = true;
            this.radioToFah.Text = "Fahrenheit(F)";
            this.radioToFah.UseVisualStyleBackColor = true;
            // 
            // radioToCels
            // 
            this.radioToCels.AutoSize = true;
            this.radioToCels.Location = new System.Drawing.Point(18, 56);
            this.radioToCels.Name = "radioToCels";
            this.radioToCels.Size = new System.Drawing.Size(109, 24);
            this.radioToCels.TabIndex = 0;
            this.radioToCels.TabStop = true;
            this.radioToCels.Text = "Celsius(C)";
            this.radioToCels.UseVisualStyleBackColor = true;
            // 
            // radioToKelv
            // 
            this.radioToKelv.AutoSize = true;
            this.radioToKelv.Location = new System.Drawing.Point(18, 86);
            this.radioToKelv.Name = "radioToKelv";
            this.radioToKelv.Size = new System.Drawing.Size(97, 24);
            this.radioToKelv.TabIndex = 0;
            this.radioToKelv.TabStop = true;
            this.radioToKelv.Text = "Kelvin(K)";
            this.radioToKelv.UseVisualStyleBackColor = true;
            // 
            // btnConvert
            // 
            this.btnConvert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnConvert.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConvert.Location = new System.Drawing.Point(22, 249);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(433, 41);
            this.btnConvert.TabIndex = 2;
            this.btnConvert.Text = "Convert";
            this.btnConvert.UseVisualStyleBackColor = false;
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.radioFromKelv);
            this.groupBox2.Controls.Add(this.radioFromCels);
            this.groupBox2.Controls.Add(this.radioFromFah);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(22, 97);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(181, 132);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "From";
            // 
            // radioFromKelv
            // 
            this.radioFromKelv.AutoSize = true;
            this.radioFromKelv.Location = new System.Drawing.Point(18, 86);
            this.radioFromKelv.Name = "radioFromKelv";
            this.radioFromKelv.Size = new System.Drawing.Size(97, 24);
            this.radioFromKelv.TabIndex = 0;
            this.radioFromKelv.TabStop = true;
            this.radioFromKelv.Text = "Kelvin(K)";
            this.radioFromKelv.UseVisualStyleBackColor = true;
            // 
            // radioFromCels
            // 
            this.radioFromCels.AutoSize = true;
            this.radioFromCels.Location = new System.Drawing.Point(18, 56);
            this.radioFromCels.Name = "radioFromCels";
            this.radioFromCels.Size = new System.Drawing.Size(109, 24);
            this.radioFromCels.TabIndex = 0;
            this.radioFromCels.TabStop = true;
            this.radioFromCels.Text = "Celsius(C)";
            this.radioFromCels.UseVisualStyleBackColor = true;
            // 
            // radioFromFah
            // 
            this.radioFromFah.AutoSize = true;
            this.radioFromFah.Location = new System.Drawing.Point(18, 25);
            this.radioFromFah.Name = "radioFromFah";
            this.radioFromFah.Size = new System.Drawing.Size(137, 24);
            this.radioFromFah.TabIndex = 0;
            this.radioFromFah.TabStop = true;
            this.radioFromFah.Text = "Fahrenheit(F)";
            this.radioFromFah.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(469, 409);
            this.Controls.Add(this.btnConvert);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Temperature Converter";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtOutput;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioToKelv;
        private System.Windows.Forms.RadioButton radioToCels;
        private System.Windows.Forms.RadioButton radioToFah;
        private System.Windows.Forms.Button btnConvert;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioFromKelv;
        private System.Windows.Forms.RadioButton radioFromCels;
        private System.Windows.Forms.RadioButton radioFromFah;
    }
}

