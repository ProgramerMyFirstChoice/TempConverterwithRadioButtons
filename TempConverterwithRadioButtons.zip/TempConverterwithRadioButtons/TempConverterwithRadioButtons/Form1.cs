﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TempConverterwithRadioButtons
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // Button click event to convert temprature
        private void btnConvert_Click(object sender, EventArgs e)
        {
            double convertedTemp = 0;
            // User input 
            double userInput;
            // Parse user input
            double.TryParse(txtInput.Text, out userInput);
            // Check the Fahrenhait and  Celsius checked
            if (radioFromFah.Checked && radioToCels.Checked)
            {
                // Convert Fahrenhait to Celsius/
                // Assign the result to convertedTemp variable
                convertedTemp = ConvertFahToCels(userInput);
            }
            // Check the Fahrenhait and Kelvin checked
            else if (radioFromFah.Checked && radioToKelv.Checked)
            {
                // Convert Fahrenhait to Kelvin
                // Assign the result to convertedTemp variable
                convertedTemp = ConvertFahToKelv(userInput);
            }
            // Check the Fahrenhait and Kelvin checked
            else if (radioFromCels.Checked && radioFromFah.Checked)
            {
                // Convert Fahrenhait to Kelvin
                // Assign the result to convertedTemp variable
                convertedTemp = ConvertFahToKelv(userInput);
            }
            // Check the Fahrenhait and Kelvin checked
            else if (radioFromCels.Checked && radioToKelv.Checked)
            {
                // Convert Fahrenhait to Kelvin
                // Assign the result to convertedTemp variable
                convertedTemp = ConvertFahToKelv(userInput);
            }
            // Check the Fahrenhait and Kelvin checked
            else if (radioFromKelv.Checked && radioFromFah.Checked)
            {
                // Convert Fahrenhait to Kelvin
                // Assign the result to convertedTemp variable
                convertedTemp = ConvertFahToKelv(userInput);
            }
            // Check the Fahrenhait and Kelvin checked
            else if (radioFromKelv.Checked && radioToCels.Checked)
            {
                // Convert Fahrenhait to Kelvin
                // Assign the result to convertedTemp variable
                convertedTemp = ConvertFahToKelv(userInput);
            }
            // Check the Fahrenhait and Fahrenhait checked
            else if (radioFromFah.Checked && radioFromFah.Checked)
            {
                // Display Error Message
                MessageBox.Show("Cannot convert Fahrenheit to Fahrenheit");
                
            }
            else if (radioToCels.Checked && radioToCels.Checked)
            {
                // Display Error Message
                MessageBox.Show("Cannot convert Fahrenheit to Fahrenheit");

            }
            else if (radioFromKelv.Checked && radioFromKelv.Checked)
            {
                // Display Error Message
                MessageBox.Show("Cannot convert Fahrenheit to Fahrenheit");

            }
            else
            {
                MessageBox.Show("Please select the temprature");
                return;
            }
            // Display the converted temprature in textOutout textbox
            txtOutput.Text = convertedTemp.ToString("n");
        }
        #region  Method to convert Temprature
        private double ConvertFahToCels(double inputTemp)
        {
            // Convert the Fahrenhait to Celsius 
            double outputTemp;
            outputTemp = (inputTemp - 32) * 5 / 9;
            return outputTemp;
        }

        private double ConvertFahToKelv(double inputTemp)
        {
            // Convert the Fahrenhait to Kelvin 
            double outputTemp;
            outputTemp = (inputTemp - 32) * 5 / 9 + 273.15;
            return outputTemp;
        }

        private double ConvertCelsToFah(double inputTemp)
        {
            // Convert the Celsius to Fahrenhait  
            double outputTemp;
            outputTemp = (inputTemp * 9 / 5) + 32;
            return outputTemp;
        }

        private double ConvertCelsToKelv(double inputTemp)
        {
            // Convert the Celsius to Kelvin
            double outputTemp;
            outputTemp = inputTemp + 273.15;
            return outputTemp;
        }

        private double ConvertKelvToFah(double inputTemp)
        {
            // Convert the Kelvin to Fahrenhait 
            double outputTemp;
            outputTemp = (inputTemp - 273.15) * 9 / 5 + 32;
            return outputTemp;
        }

        private double ConvertKelvToCels(double inputTemp)
        {
            // Convert the Kelvin to Celsius 
            double outputTemp;
            outputTemp = inputTemp - 273.15;
            return outputTemp;
        }

        #endregion
    }
}
